<html>
    <head>
        <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
 
    </head>
<body>
   <div class="container-fluid">
        <style>
        ul>li{
            
            background:#dc7373;
            margin:2px;
            border-radius:8px;
            
           
            text-align:center;
            
        }
        ul>li:hover{
            background:blue;
            
        }
        a:hover{
            color:white;
        }
        
        a.nav-link{
             font-style:italic;
             font-family:700px;
        }
    </style>
    <nav class="navbar navbar-expand-lg navbar-light bg-light ">
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav" >
    <ul class="navbar-nav" ">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home </a>
      </li>
       <li class="nav-item active">
        <a class="nav-link" href="about.php">About</a>
      </li>
       <li class="nav-item active">
        <a class="nav-link" href="contact.php">Contact</a>
      </li>
       <li class="nav-item active">
        <a class="nav-link" href="privacypolicy.php">Privacy Policy</a>
      </li>
       <li class="nav-item active">
        <a class="nav-link" href="terms.php">Terms of use</a>
      </li>
      
      
    </ul>
  </div>
</nav>
        <div class="row mt-5">
            <div class="card col-sm-6 ml-auto mr-auto">
  <h5 class="card-header bg-dark text-light">Term and Condition</h5>
  <div class="card-body">
    <h5 class="card-title">Print E Card Terms of use</h5>
    <p class="card-text">If you are using this portal then you need to share some details about you. and we want to tell everyone that we are not affiliated to government agency.</p>
     
  </div>
</div>
        </div>
   </div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>

</body>
</html>
