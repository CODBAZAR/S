<html>
    <head>
         <meta name="viewport" content="width=device-width, initial-scale=1">
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" type="text/css" rel="stylesheet"> 

    </head>
           
    <body style="background:skyblue;">
      <style>
        ul>li{
            
            background:#dc7373;
            margin:2px;
            border-radius:8px;
            
           
            text-align:center;
            
        }
        ul>li:hover{
            background:blue;
            
        }
        a:hover{
            color:white;
        }
        
        a.nav-link{
             font-style:italic;
             font-family:700px;
        }
    </style>
    <nav class="navbar navbar-expand-lg navbar-light bg-light ">
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav" >
    <ul class="navbar-nav" ">
      <li class="nav-item active">
        <a class="nav-link" href="#">Home </a>
      </li>
       <li class="nav-item active">
        <a class="nav-link" href="#">About</a>
      </li>
       <li class="nav-item active">
        <a class="nav-link" href="#">Contact</a>
      </li>
       <li class="nav-item active">
        <a class="nav-link" href="#">Privacy Policy</a>
      </li>
       <li class="nav-item active">
        <a class="nav-link" href="#">Terms of use</a>
      </li>
      
      
    </ul>
  </div>
</nav>
           
        <div class="container-fluid" >
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4602408633246044"
     crossorigin="anonymous"></script>
<!-- bannerAd -->
<ins class="adsbygoogle"
     style="display:inline-block;width:900px;height:90px"
     data-ad-client="ca-pub-4602408633246044"
     data-ad-slot="1810476122"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
            <section class="main">
                <div class="row ">
                <!--<marquee><span style="color:green;font-weight:700; background:white;margin:5px">भारत के न० 1 प्रिंट पोर्टल में आपका स्वागत है | आप यहाँ पर आधार, वोटर और पैन कार्ड जैसे सुविधाओ का लाभ उठा सकते है!</span></marquee>-->

                </div>
               <div class="row ml-auto mr-auto">
            
                    <div class="col-sm-4 col-md-4" style="padding:10px;" >
                       <div class="panel" style="border:2px dashed green; background:linear-gradient(180deg,blue,violet);">
                       
                           <div class="panel-header  p-1" style="background:#61251c!important">
                           <span style="color:white;font-weight:600">Register Form</span>
                        </div>
                            <div class="panel-body ml-2">
                                <div class="form-section ">
                               <div class="col-sm-10">
                                        
                                <form action="" method="POST" id="reg">
                                    
                                <select name="usertype" class="form-control select  m-2" id="usertype" required>
                                        <option value="">SELECT USER TYPE</option>
                                        <option value="RETAILER">RETAILER</option>
                                        <option value="DISTRIBUTER">DISTRIBUTER</option>
                                        <option value="SUPER DISTRIBUTER">SUPER DISTRIBUTER</option>
                                        <option value="MASTER ADMIN">MASTER ADMIN</option>
                                </select>
                                       
                                        <input type="text" name="name" id="name"  class="form-control m-2" placeholder="Enter Your Name Here" onkeypress='return isAlphaKey(event)' required >
                                        <input type="text" name="mobile"  id="mobile" class="form-control m-2" placeholder="Enter Mobile No (9999999999 ) " onkeypress='return isNumberKey(event)'  required>
                                        <input type="email" name="email" id="email" class="form-control m-2" placeholder="Enter Email ID (abc@example.com)">
                                     
                  <select name="state" class="form-control select  m-2" id="state" required>
                    <option value="">SELECT STATE</option>
                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                    <option value="West Bengal ">West Bengal </option>
                    <option value="Orissa">Orissa</option>
                    <option value="Bihar">Bihar</option>
                    <option value="Rajasthan">Rajasthan</option>
                    <option value="Madhya Pradesh">Madhya Pradesh</option>
                    <option value="Himachal Pradesh">Himachal Pradesh</option>
                    <option value="Punjab">Punjab</option>
                    <option value="Tamil Nadu">Tamil Nadu</option>
                    <option value="Karnataka">Karnataka</option>
                    <option value="Jharkhand">Jharkhand</option>
                    <option value="Uttarakhand">Uttarakhand</option>
                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                    <option value="Chhattisgarh">Chhattisgarh</option>
                    <option value="Assam">Assam</option>
                    <option value="Maharashtra">Maharashtra</option>
                    <option value="Haryana">Haryana</option>
                    <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                    <option value="Gujarat">Gujarat</option>
                    <option value="Tripura">Tripura</option>
                    <option value="Manipur">Manipur</option>
                    <option value="Puducherry">Puducherry</option>
                    <option value="Delhi">Delhi</option>
                    <option value="Meghalaya">Meghalaya</option>
                    <option value="Kerala">Kerala</option>
                    <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                    <option value="Chandigarh">Chandigarh</option>
                    <option value="Telangana">Telangana</option> 
                                </select>
  </form>
                                  
                                    <div class="row ml-2">
                                        <div class="m-1">
                                            <button type="submit" id="register" class="btn btn-success pl-5 pr-5" style="padding:5px 20% 5px 20%"><span style="color:white; font-weight:600">Register</span></button>
                                        </div>
                                        
                                  
                                     <div class="m-1">
                                            <a href="index.php" class="btn btn-warning pl-5 pr-5" style="padding:5px 20% 5px 20%"><span style="color:white; font-weight:600">Login</span></a>
                                        </div>
                                       
                                    </div>
                                    
                                            <div class="row">
                                            <a href="" class="mt-1 mb-2 ml-5"><span style="color:red; font-weight:600; ">Forgot Password ?</span></a>
                                            </div>
                       
                               </div>
                                </div>
                            </div>
                        </div>
                    
                    </div>

                    <div class=" col-sm-7 m-2" style="background:linear-gradient(45deg,black,transparent);" >
                    <div class="row bg-light"> <h3 class="ml-auto mr-auto text-danger ">Happy Festival Offer</h3>  </div>
                  <style>
                      span.rc{
                         font-size: 24px;
                        background: #f12a02;
                        padding: 7px 6px;
                        color: #fff;
                        width: 56px;
                        line-height: 28px;
                        text-align: initial;
                        font-weight: 700;
                        height: 50px;
                        position: absolute;
                        top:0;
                        left: 0;
                        border-bottom-right-radius: 50px;
                        box-shadow: 1px 2px 5px #000; 
                      }
                  </style>
                        <div class="row ml-auto ">
                            <div class="col-sm-5 m-1">
                                <div class="card" style="background:violet;">
                                    
                                   <div class="row m-2">
                                      
                                            <span class="rc">1</span>
                                            <h5 style="margin-left:50px;color:white">Retailer</h5>
                                           <h4 style="margin-left:10px;"> RS: 201</h4> 
                                       
                                   </div>
                                   <div class="row ml-2 mr-2">
                                       <p style="font-style:italic;">A retailer can can use all services </p>
                                   </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-5 m-1 ml-1 ">
                                <div class="card" style="background:violet;">
                                    
                                   <div class="row m-2">
                                      
                                            <span class="rc">2</span>
                                            <h5 style="margin-left:50px;color:white">Distributer</h5>
                                                 <h4 style="margin-left:10px;"> RS: 301</h4> 
                                       

                                       
                                   </div>
                                   <div class="row ml-2 mr-2">
                                       <p style="font-style:italic;">A distributer can create unlimited retailer and can use other services as well </p>
                                   </div>
                                </div>
                            </div>
                            </div>
                              <div class="row ml-auto ">
                            <div class="col-sm-5 m-1">
                                <div class="card" style="background:violet;">
                                    
                                   <div class="row m-2">
                                      
                                            <span class="rc">1</span>
                                            <h5 style="margin-left:50px;color:white">Super Distributer</h5>
                                               <h6 style="margin-left:10px;"> RS: 401</h6> 
                                       

                                       
                                   </div>
                                   <div class="row ml-2 mr-2">
                                       <p style="font-style:italic;">A  Super Distributer can create unlimited retailer and distributer and can use other services available on this portal </p>
                                   </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-5 m-1 ml-1 ">
                                <div class="card" style="background:violet;">
                                    
                                   <div class="row m-2">
                                      
                                            <span class="rc">2</span>
                                            <h5 style="margin-left:50px;color:white">Master Admin</h5>
                                                 <h4 style="margin-left:10px;"> RS: 501</h4> 
                                       

                                       
                                   </div>
                                   <div class="row ml-2 mr-2">
                                       <p style="font-style:italic;">A Master admin can create unlimited retailer, distributer and Super Distributer and can use other services also </p>
                                   </div>
                                </div>
                            </div>
                            </div>
                            
                        </div>
                  
                    </div>
               </div>
                
               <div class="row">
                    <marquee><span style="color:tomato; font-weight:700;font-size:25px;">यदि आपको इस पोर्टल का प्रयोग करने में कोई भी समस्या होती हो तो दाहिने साइड में लगे contact बटन का प्रयोग करे! और यदि आप अपना पासवर्ड भूल गए है तो <b>forgot password</b> पर क्लिक करे! </span></marquee>
               </div>
            </section>

        </div>
        
         <form  action="pay_success.php" method="POST" name="f1" >
            <input type="hidden" name="usertype" id="pusertype" value="">
            <input type="hidden" name="name" id="pname" value="">
            <input type="hidden" name="email"   id="pemail" value="">
            <input type="hidden" name="mobile" id="pmobile"  value="">
            <input type="hidden" name="state" id="pstate" value="">
            <input type="hidden" name="paymentid" id="paymentid" value="">
            <input type="hidden" name="orderid" id="orderid" value="">
            <input type="hidden" name="amt" id="amt" value="">
        </form>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <script>
             var amount;
         function isNumberKey(evt){
            var charCode = (evt.which) ? evt.which : event.keyCode
            console.log(charCode);
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return false;
            return true;
            }
            function isAlphaKey(evt){
                var charCode = (evt.which) ? evt.which : event.keyCode
            console.log(charCode);
            if (charCode > 31 && (charCode < 48 || charCode > 57))
                return true;
            return false;
            }
        </script>


<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<!-- Form Submit Hanlder Here -->
<script>
   var amount=1000;
    $('#register').on('click',()=>{
        if($('#usertype').val()==="") {
            alert("Please Select usertype");
            return false;
        }
        if($('#name').val()==="") {
            alert("Please Enter name");
            return false;
        }
        if($('#mobile').val()==="") {
            alert("Please Enter mobile");
            return false;
        }
        if($('#email').val()==="") {
            alert("Please Enter email");
            return false;
        }
        if($('#state').val()==="") {
            alert("Please Select state");
            return false;
        }



        var formData = new FormData();
        formData.append('mobile',$('#mobile').val());
        formData.append('email',$('#email').val());
        formData.append('usertype',$('#usertype').val());

        $.ajax({
        url:'check_user.php',
        type:'POST',
        data:formData,
        dataType:'json',
        contentType:false,
        processData:false
        }).done((response)=>{
            if(response.message=="fail"){
                alert("User Exist");
            }
            if(response.message=="success"){
                amount=response.amount;
                $('#amt').val(amount+"00");
                let usertype= $('#usertype').val();
                let name = $('#name').val();
                let email = $('#email').val();
                let state = $('#state').val();
                let mobile = $('#mobile').val();
                var d = btoa(usertype+"_"+name+"_"+email+"_"+state+"_"+mobile);
                
                window.location.href="regpaytm/index.php?data="+d;
                }

                  
                console.log(response);
        });
    
  });
     
   
 
 
</script>

 <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4602408633246044"
     crossorigin="anonymous"></script>
<!-- bannerAd -->
<ins class="adsbygoogle"
     style="display:inline-block;width:900px;height:90px"
     data-ad-client="ca-pub-4602408633246044"
     data-ad-slot="1810476122"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
    </body>
</html>