

<head>
   <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-115978502-7"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-115978502-7');
</script>
<!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">-->
<!--<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>-->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
      
<meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
   <link href="https://fonts.googleapis.com/css?family=Inconsolata" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
  <link rel="stylesheet" href="https://pattern.kivan-works.com/fonts/kredit.css">
</head>

<body style="background:#6590d0">
    <style>
        ul>li{
            
            background:skyblue;
            margin:2px;
            border-radius:8px;
            
           
            text-align:center;
            
        }
        a.nav-link{
             font-style:italic;
             font-family:700px;
        }
    </style>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="index.php">Home </a>
      </li>
       <li class="nav-item active">
        <a class="nav-link" href="about.php">About</a>
      </li>
       <li class="nav-item active">
        <a class="nav-link" href="contact.php">Contact</a>
      </li>
       <li class="nav-item active">
        <a class="nav-link" href="privacypolicy.php">Privacy Policy</a>
      </li>
       <li class="nav-item active">
        <a class="nav-link" href="terms.php">Terms of use</a>
      </li>
      <li class="nav-item active">
        <a class="nav-link" href="refund.php">Refund and Cancellation</a>
      </li>
      
      
    </ul>
  </div>
</nav>
    <div class="container-fluid">
  

  
        <div class="col-lg-8 col-sm-8 col-xs-8 ml-auto mr-auto mt-5">
          <div class="card" style="background: #fff0f0;">
 
                      <div class="card-header text-uppercase text-white text-center bg-dark">Welcome to Print Portal</div>

                   <div class="card-body">
          <div class="row">
            <div class="col-sm-6 ml-auto mr-auto">
            <form action="" method="POST" >
              <div class="row mt-2">
                <div class="col-sm-3">Username:</div>
                <div class="col-sm-8  "><input type="text" name="mobile" id="username" class="form-control" placeholder="Mobile"></div>
              </div>
              <div class="row mt-2">
                <div class="col-sm-3">Password:</div>
                <div class="col-sm-8  "><input type="password" name="password" id="password" class="form-control" placeholder="Password"></div>
              </div>
              <div class="row mt-2">
                <div class="col-sm-3"></div>
                <div class="col-sm-8  ">
                   <button type="submit" name="login" class="btn btn-success m-3 " style="padding-left:30%;padding-right:30%; margin:20%">Login</button>
                  </div>
              </div>
              
            </form>
            <div class="row">
              <div class="col-sm-6">
                <a href="reg.php"><span style="color:blue;font-weight:600">Register Here</span></a>
              </div>
              <div class="col-sm-6" >
                <a href=""><span style="color:red;font-weight:600">Forgot Password</span></a>
              </div>
            </div>
            </div>
            <div class="col-sm-6 col-md-6">
                <div class="card">
                    <div class="card-header text-center">
                  <h4> Contact:</h4>
                  
                    
                    </div>
                   <div class="card-body">
                        <div class="row">
                            <h3><span>Whatsapp:</span> <a href="https://wa.me/917897419935">+917897419935</a></h3>
                        </div>
                    
                   </div>
                </div>
            </div>
          </div>


         </div>
                      
            
</div>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-4602408633246044"
     crossorigin="anonymous"></script>
<!-- banner1200_300 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-4602408633246044"
     data-ad-slot="3168608060"
     data-ad-format="auto"
     data-full-width-responsive="true"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
       
         <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

       <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
       
        </div>
    </div>
    <footer class="mt-auto">
          

       
    </footer>
  
</body>